package com.jhon.apisenatiretrofit.datos.modelos

import android.R

data class Persona (

    val nombre: String,
    val apellido: String,
    val id: Int = 0,
    val create_at: String = ""
)
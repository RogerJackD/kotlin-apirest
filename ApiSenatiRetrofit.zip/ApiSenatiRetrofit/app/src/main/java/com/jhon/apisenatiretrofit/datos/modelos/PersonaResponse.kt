package com.jhon.apisenatiretrofit.datos.modelos

data class PersonaResponse (
    val invitados: List<Persona>
)
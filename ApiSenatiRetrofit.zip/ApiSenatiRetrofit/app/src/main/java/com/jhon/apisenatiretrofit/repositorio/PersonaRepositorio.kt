package com.jhon.apisenatiretrofit.repositorio

import com.jhon.apisenatiretrofit.datos.modelos.Persona
import com.jhon.apisenatiretrofit.datos.modelos.PersonaResponse
import com.jhon.apisenatiretrofit.datos.red.ClienteRetrofit

class PersonaRepositorio {
    private val api = ClienteRetrofit.apiService

    suspend fun obtenerPersonas(): PersonaResponse {

        val respuesta: PersonaResponse

        try {
            respuesta= api.obtenerPersonas()
        } catch (e: Exception) {
            return PersonaResponse(emptyList())
        }

        return respuesta
    }

    suspend fun agregarPersona(persona: Persona): Boolean{
        return try {
            val response = api.agregarPersona(persona)
            response.isSuccessful
        } catch (e: Exception){
            false
        }

    }
}